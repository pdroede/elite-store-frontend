# Elite Store - Live Site

🚀 **SITE AO VIVO:** https://pdroede.github.io/EliteStore-Frontend/

✅ **BACKEND API:** https://elite-store-backend.onrender.com
✅ **ADMIN DASHBOARD:** https://elite-store-backend.onrender.com/admin

## Status
- ✅ Pagamentos LIVE ativos
- ✅ Sistema de pedidos funcionando
- ✅ Coleta de dados completa dos clientes

## Links Rápidos
- 🛒 [Loja Online](https://pdroede.github.io/EliteStore-Frontend/)
- 📊 [Dashboard Admin](https://elite-store-backend.onrender.com/admin)
- 🔧 [Status da API](https://elite-store-backend.onrender.com)

